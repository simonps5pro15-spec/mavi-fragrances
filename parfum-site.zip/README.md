# Сайт парфюмерии + админка (DE/EN)

Сайт (Netlify) + Firebase (вход и база). Админка: `/admin/`.

## Что есть
- Переключатель DE/EN сверху, меню «три полоски» (Start, Kollektion, Свои духи, ИИ-консультант, О нас, Контакты).
- «Создать свои духи»: клиент выбирает ноты, размер, название → заявка.
- «ИИ-консультант»: клиент описывает желаемые ароматы → ИИ подбирает из вашего каталога → заявка.
- Админка: товары (DE+EN, фото), ноты конструктора, заявки, все тексты (DE+EN), размеры/цены, инструкции для ИИ, e-mail и WhatsApp, КУДА уходят заявки.

## Запуск
1. https://console.firebase.google.com → новый проект.
2. Authentication → включить **Email/Password**.
3. Firestore Database → Create → вкладка **Rules** → вставить `firestore.rules` → Publish.
4. Project settings → Web app (`</>`) → значения в `firebase-config.js`.
5. Деплой на Netlify **через GitHub или Netlify CLI** (`netlify deploy --prod`), не drag&drop — иначе не заработает папка `netlify/functions` (ИИ). Без неё сайт всё равно работает: подбор идёт по ключевым словам.
6. ИИ: Netlify → Site settings → Environment variables → `ANTHROPIC_API_KEY` (ключ с console.anthropic.com). Поставьте лимит расходов в консоли Anthropic.
7. Откройте `/admin/` — первый зарегистрировавшийся становится владельцем.

## Логотип и дизайн
`logo.png` и `favicon.ico` в корень. Цвета/шрифты — блок `:root` в `index.html` и `admin/index.html`.
