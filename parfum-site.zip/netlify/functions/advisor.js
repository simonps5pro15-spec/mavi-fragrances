// ИИ-консультант: ключ хранится на сервере (Netlify → Environment variables → ANTHROPIC_API_KEY)
exports.handler = async (e) => {
  if (e.httpMethod !== 'POST') return { statusCode: 405, body: '' };
  try {
    const { text = '', lang = 'de', style = '', catalog = {} } = JSON.parse(e.body || '{}');
    const system = `You are a perfume advisor for an online perfumery. ${String(style).slice(0, 800)}
Reply in ${lang === 'en' ? 'English' : 'German'}. Recommend only from the catalog. Return ONLY JSON:
{"message":"2-3 friendly sentences","picks":["exact product names, max 3"],"notes":["exact note names from catalog, max 5"]}
Catalog: ${JSON.stringify(catalog).slice(0, 6000)}`;
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: 'claude-haiku-4-5-20251001', max_tokens: 500, system, messages: [{ role: 'user', content: String(text).slice(0, 600) }] })
    });
    const j = await r.json();
    const t = ((j.content && j.content[0] && j.content[0].text) || '').replace(/```json|```/g, '').trim();
    return { statusCode: 200, headers: { 'content-type': 'application/json' }, body: JSON.stringify(JSON.parse(t)) };
  } catch (err) { return { statusCode: 500, body: '{}' }; }
};
