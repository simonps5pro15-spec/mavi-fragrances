// Данные проекта Firebase «mavi-fragrances»
window.FB_CONFIG = {
  apiKey: "AIzaSyBveG7Te91W10-2YCnZv3Q9tVhkWEnkvP4",
  authDomain: "mavi-fragrances.firebaseapp.com",
  projectId: "mavi-fragrances",
  storageBucket: "mavi-fragrances.firebasestorage.app",
  messagingSenderId: "457023465757",
  appId: "1:457023465757:web:6432de0e1be28d4c5b19f4"
};
